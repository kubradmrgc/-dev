# Kütüphane Asistanı
Java ile geliştirilen Kütüphane Asistanı.<br><b>Blog:</b> https://www.eminsaygi.com <br><b> Linkedin:</b> https://www.linkedin.com/in/eminsaygı

<b> Kullanılan Teknolojiler: </b>

Java SE  ile geliştirilmiştir.
Arayüz Java Swing ile geliştirilmiştir.
MVC mimari deseni kullanılmıştır.
Veritabanı Mysql olup Hibernate teknolojisi kullanılmıştır.<br>

<b>Kullanım kılavuzu ve Bilgi : https://pastebin.pl/view/7562e1ef
  
<b>Kütüphane Asistanı içinden Görüntüler</b>

<b>Giriş</b>

<img src="https://github.com/eminsaygi/KutuphaneAsistani/blob/master/images/giriş.PNG"></a>

<b>Kayıt Ol</b>

<img src="https://github.com/eminsaygi/KutuphaneAsistani/blob/master/images/kayıt.PNG"></a>

<b>Ana Gövde</b>

<img src="https://github.com/eminsaygi/KutuphaneAsistani/blob/master/images/ana%20ekran.PNG"></a>
