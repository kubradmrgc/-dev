
package com.eminsaygi.kutuphane;




/**
 *
 * @author Emin
 */

/*

Databese bilgilerimizi burda tutuyoruz.

*/
public class Database {
   
    public static final String db_name="db_name";
    public static final String db_user="db_user";
    public static final String db_pass="db_pass";
    public static final String db_host="db_host";
    public static final int    db_port=3306;
    
}
