>>KURULUM<<

>'Kutuphane Asistanı.exe'adlı exe dosyasnın bulunduğu dosya konumunda lib klasörü olması gerekiyor.
> lib klasörünün içinde 'AbsoluteLayout-RELEASE113.jar' ve 'mysql-connector-java-5.1.48-bin.jar' adlı iki jar dosyası olması gerekiyor.
>Yok ise http://java.com/download [73MB] burdan jre dosyasımızı indiriyoruz.
>MYSQL Databes hosting üzerine kayıtlı olduğu için hergangi bir ek işlem yapmanıza gerek yok.
>Buraya kadar her şey tamam ise 'Kutuphane Asistanı.exe' adlı exe dosyasına çift tıklamanız yeterli.


>>OTOMASYON İÇİNDEKİ HİZMETLER<<

>GİRİŞ HİZMETİ
>KAYIT OLMA HİZMETİ
>CAPTCHA DOĞRULAMASI
>DATABES'E VE TABLOYA;
*VERİ EKLEME
*VERİ SİLME
*VERİ GÜNCELLEME
>TABLODA VERİ ARAMA
>GELİŞTİRİCEYE GERİ DÖNÜŞ SEÇENEĞİ


>>KULLANIM TALİMATLARI<<

>GİRİŞ<
*Kullanıcı adı ve parolayı biliyorsanız giriş yapabilirsiniz.Kaydınız yok ise kayıt yapabilirsiniz.

>KAYIT<
*Kullanıcı adınızı giriniz.
*Şifrenizi giriniz ve doğrulayınız.
*CAPTCHA kodunu doğru giriniz.

>KİTAP EKLEME-GÜNCELLEME-SİLME-ARAMA İŞLEMLERİ<
*Kitap EKLEME:Kitap Bilgilerini eksiksiz doldurup,'Kitap Ekle' seçeneğine tıklayınız.
*Kitap GÜNCELLEME: Tablodan kitap seçip,seçtiğiniz kitabın bilgilerini 'Kitap Güncelle' seçeneğine tıklayıp gerçekleştirebilirsiniz.
*Kitap SİLME : Tablodan kitap seçip,seçtiğiniz kitabın bilgilerini 'Kitap Sil' seçeneğine tıklayıp gerçekleştirebilirsiniz.
*Kitap ARAMA : Aramak istediğiniz kelimeyi 'Arama Çubuğu' na girerek. Arama işlemini gerçekleştirebilirsiniz.